/*
 * global.c
 *
 *  Created on: Nov 4, 2023
 *      Author: Asus
 */

#include "global.h"
int status = 0;
