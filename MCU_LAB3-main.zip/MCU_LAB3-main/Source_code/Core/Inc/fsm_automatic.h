/*
 * fsm_automatic.h
 *
 *  Created on: Nov 4, 2023
 *      Author: Asus
 */

#ifndef INC_FSM_AUTOMATIC_H_
#define INC_FSM_AUTOMATIC_H_

#include "global.h"

void fsm_automatic_run();

#endif /* INC_FSM_AUTOMATIC_H_ */
